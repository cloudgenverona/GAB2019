﻿namespace Gab.Base.Navigation
{
    public static class NavigationContainerNames
    {
        public const string DefaultContainer = "DefaultContainer";
        public const string LoginContainer = "LoginContainer";
        public const string MainContainer = "MainContainer";
    }
}
