﻿using System;

namespace Gab.Base.Grouping
{
    public class DateTimeGroupKey : GroupKey
    {
        public DateTime DateTime { get; set; }
    }
}
