﻿namespace Gab.Cells
{
	public partial class EventCell : BaseCell
	{
		public EventCell()
		{
			InitializeComponent ();
		}
	}
}