﻿namespace Gab.Cells
{
	public partial class MeetingRoomCell : BaseCell
	{
		public MeetingRoomCell ()
		{
			InitializeComponent ();
		}
	}
}