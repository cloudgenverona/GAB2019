﻿namespace Gab.Shared.Messages
{
    public static class ErrorMessages
    {
        public const string GenericErrorMessage = "GenericErrorMessage";
        public const string RoomItWillBeBusySoonMessage = "RoomItWillBeBusySoonMessage";       
    }
}
