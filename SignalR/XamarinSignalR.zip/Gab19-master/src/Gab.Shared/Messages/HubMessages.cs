﻿namespace Gab.Shared.Messages
{
    public static class HubMessages
    {
        public const string EventChanged = "EventChanged";  
    }
}
