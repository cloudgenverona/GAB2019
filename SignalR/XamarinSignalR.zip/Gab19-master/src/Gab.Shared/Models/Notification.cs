﻿namespace Gab.Shared.Models
{
    public class Notification
    {
        public Resource Resource { get; set; }
        public string ChangeType { get; set; }
    }
}
