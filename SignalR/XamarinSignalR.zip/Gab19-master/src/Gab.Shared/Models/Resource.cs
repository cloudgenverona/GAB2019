﻿namespace Gab.Shared.Models
{
    public class Resource
    {
        public string Id { get; set; }
        public string Path { get; set; }
    }
}
