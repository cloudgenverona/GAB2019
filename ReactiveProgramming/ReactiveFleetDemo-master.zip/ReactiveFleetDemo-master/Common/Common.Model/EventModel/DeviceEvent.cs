﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Model.EventModel
{
    public class DeviceEvent : BaseEvent
    {
        
    }
}
