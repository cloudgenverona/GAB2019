﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Model.Enum
{
    public class ActivationType
    {
        
        public enum Type
        {
            None = 0,
            Started = 1,
            Stopped = 2
        }

    }
}
