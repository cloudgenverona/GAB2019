﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Service.Status.Data
{
    static class Repository
    {
    }
}
